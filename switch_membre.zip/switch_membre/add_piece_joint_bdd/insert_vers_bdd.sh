#!/bin/sh
wget --no-check-certificate  https://192.168.1.110/mailing/hps/switch_membre/add_piece_joint_bdd/file_banks_csv.php -O /var/www/html/mailing/hps/switch_membre/add_piece_joint_bdd/log/file_banks_csv.html
wget --no-check-certificate  https://192.168.1.110/mailing/hps/switch_membre/add_piece_joint_bdd/file_rejet_per_hour_csv.php -O /var/www/html/mailing/hps/switch_membre/add_piece_joint_bdd/log/file_rejet_per_hour_csv.html
wget --no-check-certificate  https://192.168.1.110/mailing/hps/switch_membre/add_piece_joint_bdd/file_rejet_per_hour_global_csv.php -O /var/www/html/mailing/hps/switch_membre/add_piece_joint_bdd/log/file_rejet_per_hour_global_csv.html
wget --no-check-certificate  https://192.168.1.110/mailing/hps/switch_membre/add_piece_joint_bdd/file_dispo_csv.php -O /var/www/html/mailing/hps/switch_membre/add_piece_joint_bdd/log/file_dispo_csv.html
wget --no-check-certificate  https://192.168.1.110/mailing/hps/switch_membre/add_piece_joint_bdd/file_mccpo_csv.php -O /var/www/html/mailing/hps/switch_membre/add_piece_joint_bdd/log/file_mccpo_csv.html
wget --no-check-certificate  https://192.168.1.110/mailing/hps/switch_membre/add_piece_joint_bdd/file_picko_csv.php -O /var/www/html/mailing/hps/switch_membre/add_piece_joint_bdd/log/file_picko_csv.html
wget --no-check-certificate  https://192.168.1.110/mailing/hps/switch_membre/add_piece_joint_bdd/file_rejet_csv.php -O /var/www/html/mailing/hps/switch_membre/add_piece_joint_bdd/log/file_rejet_csv.html
wget --no-check-certificate  https://192.168.1.110/mailing/hps/switch_membre/add_piece_joint_bdd/file_timet_per_hour_global_csv.php -O /var/www/html/mailing/hps/switch_membre/add_piece_joint_bdd/log/file_timet_per_hour_global_csv.html
echo "" > /var/mail/root



# https://192.168.1.110/mailing/hps/switch_membre/add_piece_joint_bdd/log/file_banks_csv.html
# https://192.168.1.110/mailing/hps/switch_membre/add_piece_joint_bdd/log/activite_transactionnelle_csv.html
# https://192.168.1.110/mailing/hps/switch_membre/add_piece_joint_bdd/log/file_rejet_per_hour_csv.html
# https://192.168.1.110/mailing/hps/switch_membre/add_piece_joint_bdd/log/file_rejet_per_hour_global_csv.html
# https://192.168.1.110/mailing/hps/switch_membre/add_piece_joint_bdd/log/file_dispo_csv.html
# https://192.168.1.110/mailing/hps/switch_membre/add_piece_joint_bdd/log/file_mccpo_csv.html
# https://192.168.1.110/mailing/hps/switch_membre/add_piece_joint_bdd/log/file_picko_csv.html
# https://192.168.1.110/mailing/hps/switch_membre/add_piece_joint_bdd/log/file_rejet_csv.html
# https://192.168.1.110/mailing/hps/switch_membre/add_piece_joint_bdd/log/file_timet_per_hour_global_csv.html



# bash /var/www/html/mailing/hps/switch_membre/add_piece_joint_bdd/insert_vers_bdd.sh


# $date_inscription = '15/09/2010';
 
# $date_inscription_exploded = explode('/', $date_inscription);
 
# echo $date_inscription_exploded[1];
 
# switch ($date_inscription_exploded[1])
# {
	# case 01:
		# $mois_inscription = ' janvier ';
		# break;
 
	# case 02:
		# $mois_inscription = ' février ';
		# break;
 
	# case 03:
		# $mois_inscription = ' mars ';
		# break;
 
	# case 04:
		# $mois_inscription = ' avril ';
		# break;
 
	# case 05:
		# $mois_inscription = ' mai ';
		# break;
 
	# case 06:
		# $mois_inscription = ' juin ';
		# break;
 
	# case 07:
		# $mois_inscription = ' juillet ';
		# break;
 
	# case 08:
		# $mois_inscription = ' août ';
		# break;
 
	# case 09:
		# $mois_inscription = ' septembre ';
		# break;
 
	# case 10:
		# $mois_inscription = ' octobre ';
		# break;
 
	# case 11:
		# $mois_inscription = ' novembre ';
		# break;
 
	# case 12:
		# $mois_inscription = ' décembre ';
# }
 
# echo $mois_inscription;
