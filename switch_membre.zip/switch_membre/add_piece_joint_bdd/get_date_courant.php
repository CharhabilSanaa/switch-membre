<?php
// $date_courant=date("Y-m-d", mktime(date("H")+regle_heure_backoffice(), date("i"), date("s"),date("m"),date("d")-1,date("Y")));
// $dt_courant=date("dmY", mktime(date("H")+regle_heure_backoffice(), date("i"), date("s"),date("m"),date("d")-1,date("Y")));
	$date_courant='2022-05-13';
	$dt_courant='13052022';
?>